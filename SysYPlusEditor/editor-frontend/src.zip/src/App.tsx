import Editor from "@monaco-editor/react";
import { useRef, useState } from "react";
import { registerSysYPlusLanguage } from "./sysyplus";
import type * as monacoType from "monaco-editor";
import React from "react";
import { JsonView } from 'react-json-view-lite';
import 'react-json-view-lite/dist/index.css';
import * as Y from 'yjs';
// @ts-expect-error: y-websocket 没有类型声明，忽略类型检查
import { WebsocketProvider } from 'y-websocket';
import { MonacoBinding } from 'y-monaco';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import { parseCode } from './sysyplus'; // 导入 parseCode

type ScopeVar = {
  type: string;
  isConst: boolean;
  initialized: boolean;
  length?: number;
  line: number;  // 添加声明行号
  usages: number[];  // 添加使用位置数组
};

// 添加一个新的接口来跟踪结构体成员
interface StructMember {
  name: string;
  type: string;
  structName: string;
}

function App() {
  const monacoRef = useRef<typeof monacoType | null>(null);
  const editorRef = useRef<any>(null);
  const [output, setOutput] = useState<string>("");
  const [ast, setAst] = useState<any>(null);
  const [mode, setMode] = useState<'code' | 'rich'>('code');
  const [richValue, setRichValue] = useState<string>('');

  function handleEditorWillMount(monaco: typeof monacoType) {
    registerSysYPlusLanguage(monaco);
    monacoRef.current = monaco;

    // 支持同名变量多作用域悬停显示，并展示作用域深度和所在函数
    monaco.languages.registerHoverProvider("sysyplus", {
      provideHover: function (model, position) {
        const word = model.getWordAtPosition(position);
        if (!word) return null;
        const code = model.getValue();
        const lines = code.split("\n");
        // 记录每个变量的作用域深度和所在函数
        const foundVars: { type: string; name: string; line: number; scope: number; func: string }[] = [];

        let scopeDepth = 0;
        let currentFunc = "全局";
        let inStructScope = false; // 添加结构体作用域标记
        let currentStructName = ""; // 添加当前结构体名称

        // 在函数开始处添加一个数组来存储结构体成员
        const structMembers: StructMember[] = [];

        for (let idx = 0; idx < lines.length; idx++) {
          const line = lines[idx];

          // 检查是否进入结构体定义
          const structMatch = line.match(/\bstruct\s+([a-zA-Z_]\w*)\s*\{/);
          if (structMatch) {
            inStructScope = true;
            currentStructName = structMatch[1];
            structMembers.length = 0;
            continue; // 结构体头部不做变量检测
          }

          // 检查是否离开结构体定义
          if (inStructScope && line.includes('}')) {
            inStructScope = false;
            currentStructName = "";
            structMembers.length = 0;
            continue; // 结构体尾部不做变量检测
          }

          // 在结构体作用域内检测成员变量
          if (inStructScope) {
            const memberMatch = line.match(/\b(?:const\s+)?(int|float|char)\s+([a-zA-Z_]\w*)/);
            if (memberMatch) {
              structMembers.push({
                name: memberMatch[2],
                type: memberMatch[1],
                structName: currentStructName
              });
              // 只在结构体内部推入 foundVars
              if (memberMatch[2] === word.word) {
                foundVars.push({
                  type: memberMatch[1],
                  name: memberMatch[2],
                  line: idx + 1,
                  scope: -1,
                  func: `结构体${currentStructName}的成员`
                });
              }
            }
            continue; // 结构体成员行不再做普通变量检测
          }

          // 检查是否进入函数头
          const funcMatch = line.match(/\b(int|float|char|void)\s+([a-zA-Z_]\w*)\s*\(/);
          if (funcMatch) {
            currentFunc = funcMatch[2];
          }

          // 统计作用域深度
          const openBraces = (line.match(/{/g) || []).length;
          const closeBraces = (line.match(/}/g) || []).length;

          // 只有在结构体作用域外才检测普通变量
          if (!inStructScope) {
            const match = line.match(/\b(?:const\s+)?(int|float|char|struct\s+[a-zA-Z_]\w*)\s+([a-zA-Z_]\w*)/);
            if (match && match[2] === word.word) {
              foundVars.push({
                type: match[1],
                name: match[2],
                line: idx + 1,
                scope: scopeDepth,
                func: currentFunc
              });
            }
          }

          scopeDepth += openBraces - closeBraces;
          if (scopeDepth < 0) scopeDepth = 0;

          // 检查是否离开函数体
          if (closeBraces > 0 && scopeDepth === 0 && !inStructScope) {
            currentFunc = "全局";
          }
        }

        // 修改悬停提示的显示逻辑
        if (foundVars.length > 0) {
          return {
            range: new monaco.Range(
              position.lineNumber,
              word.startColumn,
              position.lineNumber,
              word.endColumn
            ),
            contents: [
              {
                value: `**变量名**: \`${word.word}\`\n\n` +
                  foundVars.map(v => {
                    if (v.scope === -1) {
                      // 结构体成员的显示格式
                      return `- **类型**: \`${v.type}\`，**定义位置**: 第 ${v.line} 行，**作用域**: ${v.func}`;
                    } else {
                      // 普通变量的显示格式
                      return `- **类型**: \`${v.type}\`，**定义位置**: 第 ${v.line} 行，**作用域**: ${v.scope === 0 ? '全局' : `局部(深度${v.scope})`
                        }，**所在**: ${v.func}`;
                    }
                  }).join('\n')
              }
            ]
          };
        }
        return null;
      }
    });
  }

  function handleEditorDidMount(editor: any, monaco: typeof monacoType) {
    editorRef.current = editor;

    // 协同编辑初始化
    const ydoc = new Y.Doc();
    // 'sysyplus-room' 可自定义为你的文档唯一标识
    const provider = new WebsocketProvider('ws://localhost:1234', 'sysyplus-room', ydoc);
    const yText = ydoc.getText('monaco');
    // 绑定 Monaco 和 Yjs
    const monacoBinding = new MonacoBinding(
      yText,
      editorRef.current.getModel(),
      new Set([editorRef.current]),
      provider.awareness
    );
  }

  // 简单语法检查：变量名不能用关键字
  function handleEditorChange(value: string | undefined) {
    if (!monacoRef.current || !editorRef.current) return;
    const model = editorRef.current.getModel();

    if (value) {
      const { errors } = parseCode(value);

      // 添加分号检查
      const lines = value.split('\n');
      const semicolonErrors = lines.map((line, index) => {
        const trimmedLine = line.trim();
        const lineNumber = index + 1;

        // 跳过注释行
        if (
          trimmedLine.startsWith('//') ||
          trimmedLine.startsWith('/*') ||
          trimmedLine.endsWith('*/')
        ) {
          return null;
        }

        // 跳过只有大括号的行
        if (trimmedLine === '{' || trimmedLine === '}') {
          return null;
        }

        // 只检查注释前的部分
        const lineCommentIndex = line.indexOf('//');
        const beforeComment =
          lineCommentIndex !== -1
            ? line.substring(0, lineCommentIndex).trim()
            : trimmedLine;

        // 跳过空行、只包含大括号的行
        if (
          !beforeComment ||
          beforeComment === '{' ||
          beforeComment === '}' ||
          beforeComment === '{}' ||
          beforeComment.endsWith(';') ||
          beforeComment.endsWith(';}') ||
          beforeComment.endsWith('{}')
        ) {
          return null;
        }

        // 跳过语句块头部（如 struct、if、while、for、else、do 等）
        if (
          /^struct\s+[a-zA-Z_]\w*\s*\{?$/.test(beforeComment) ||
          /^(if|while|for|else|do)\b.*\{\s*$/.test(beforeComment) ||
          /^(if|while|for|else|do)\b.*$/.test(beforeComment) && beforeComment.endsWith(')')
        ) {
          return null;
        }

        // 跳过函数声明行
        if (
          beforeComment.match(
            /\b(int|float|char|void)\s+[a-zA-Z_]\w*\s*\([^)]*\)\s*{?\s*$/
          )
        ) {
          return null;
        }

        return {
          severity: monacoRef.current!.MarkerSeverity.Error,
          message: '语句末尾缺少分号',
          startLineNumber: lineNumber,
          startColumn: line.length + 1,
          endLineNumber: lineNumber,
          endColumn: line.length + 1
        };
      }).filter(error => error !== null);

      // 合并原有错误和分号错误
      monacoRef.current!.editor.setModelMarkers(
        model,
        "owner",
        [...errors, ...(semicolonErrors as monacoType.editor.IMarkerData[])]
      );
    } else {
      monacoRef.current!.editor.setModelMarkers(model, "owner", []);
    }
  }

  // 导出代码
  function handleExport() {
    const code = editorRef.current?.getValue() || "";
    const blob = new Blob([code], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "code.syy";
    a.click();
    URL.revokeObjectURL(url);
  }

  // 导入代码
  function handleImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      editorRef.current?.setValue(text);
    };
    reader.readAsText(file);
  }

  // 代码格式化函数
  function handleFormat() {
    const code = editorRef.current?.getValue() || "";
    const lines = code.split("\n");
    let indent = 0;
    const formatted: string[] = [];
    lines.forEach((rawLine: string) => {
      let line = rawLine.trim();
      if (line.endsWith("}")) indent--;
      if (indent < 0) indent = 0;
      formatted.push("  ".repeat(indent) + line);
      if (line.endsWith("{")) indent++;
    });
    editorRef.current?.setValue(formatted.join("\n"));
  }

  // 编译并运行代码
  async function handleCompileAndRun() {
    const code = editorRef.current?.getValue() || "";
    const res = await fetch("http://localhost:3001/api/runSysYPlus", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ code })
    });
    if (res.ok) {
      const data = await res.json();
      setOutput(data.output);
    } else {
      setOutput("编译失败，请检查后端服务");
    }
  }

  // 简单 AST 解析函数（可后续替换为更强 parser）
  function parseSysYPlusAST(code: string) {
    const ast: any = { type: 'Program', body: [] };
    // 匹配变量声明
    const varRegex = /^\s*(int|float|char)\s+([a-zA-Z_]\w*)\s*;/gm;
    let match;
    while ((match = varRegex.exec(code))) {
      ast.body.push({ type: 'VariableDeclaration', varType: match[1], name: match[2] });
    }
    // 匹配结构体声明
    const structRegex = /struct\s+([a-zA-Z_]\w*)\s*{([^}]*)}/gm;
    while ((match = structRegex.exec(code))) {
      ast.body.push({
        type: 'StructDeclaration',
        name: match[1],
        members: match[2]
          .split(';')
          .map(m => m.trim())
          .filter(Boolean)
          .map(m => {
            const mm = m.match(/(int|float|char)\s+([a-zA-Z_]\w*)/);
            return mm ? { type: mm[1], name: mm[2] } : null;
          })
          .filter(Boolean)
      });
    }
    // 匹配函数声明
    const funcRegex = /(int|float|char|void)\s+([a-zA-Z_]\w*)\s*\(([^)]*)\)\s*{[^}]*}/gm;
    while ((match = funcRegex.exec(code))) {
      ast.body.push({
        type: 'FunctionDeclaration',
        returnType: match[1],
        name: match[2],
        params: match[3]
          ? match[3].split(',').map(p => p.trim()).filter(Boolean)
          : []
      });
    }
    return ast;
  }

  // AST 可视化按钮
  function handleShowAST() {
    const code = editorRef.current?.getValue() || "";
    const astResult = parseSysYPlusAST(code);
    console.log("AST:", astResult);
    setAst(astResult);
  }

  // Tiptap 富文本编辑器实例
  const tiptap = useEditor({
    extensions: [
      StarterKit,
      Image,
      Table,
      TableRow,
      TableCell,
      TableHeader,
    ],
    content: richValue,
    onUpdate: ({ editor }) => {
      setRichValue(editor.getHTML());
    },
  });

  // 切换编辑模式
  function handleToggleMode() {
    if (mode === 'code') {
      // 代码 -> 富文本
      const code = editorRef.current?.getValue() || '';
      setRichValue(`<pre>${code.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>`);
      setMode('rich');
      setTimeout(() => {
        tiptap?.commands.setContent(`<pre>${code.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>`);
      }, 0);
    } else {
      // 富文本 -> 代码
      const text = tiptap?.getText() || '';
      editorRef.current?.setValue(text);
      setMode('code');
    }
  }

  return (
    <div>
      <button onClick={handleExport}>导出代码</button>
      <input
        type="file"
        accept=".sy,.c,.txt"
        style={{ display: "inline-block", marginLeft: 8 }}
        onChange={handleImport}
      />
      <button onClick={handleFormat} style={{ marginLeft: 8 }}>格式化代码</button>
      <button onClick={handleCompileAndRun} style={{ marginLeft: 8 }}>编译并运行</button>
      <button onClick={handleShowAST} style={{ marginLeft: 8 }}>AST 可视化</button>
      <button onClick={handleToggleMode} style={{ marginLeft: 8 }}>
        {mode === 'code' ? '切换为富文本编辑' : '切换为源码编辑'}
      </button>
      {mode === 'code' ? (
        <Editor
          height="90vh"
          defaultLanguage="sysyplus"
          defaultValue="// 这里写SysY+代码"
          beforeMount={handleEditorWillMount}
          onMount={handleEditorDidMount}
          onChange={handleEditorChange}
          options={{
            renameOnType: true,
            formatOnType: true,
            formatOnPaste: true
          }}
        />
      ) : (
        <div style={{ background: '#fff', minHeight: '90vh', padding: 16 }}>
          <EditorContent editor={tiptap} />
        </div>
      )}
      <div style={{ marginTop: 20 }}>
        <strong>输出结果：</strong>
        <pre>{output}</pre>
      </div>
      <div style={{ marginTop: 20, background: '#222', color: '#fff', padding: 8 }}>
        <strong>AST 可视化：</strong>
        <div style={{ fontSize: 12, color: '#aaa', marginBottom: 4 }}>
          {ast && ast.body && ast.body.length > 0
            ? 'AST 结构如下：'
            : '未能解析出 AST 节点（请检查代码或扩展解析器）'}
        </div>
        <JsonView data={ast || {}} />
        <pre>{JSON.stringify(ast, null, 2)}</pre>
      </div>
    </div>
  );
}

export default App;
